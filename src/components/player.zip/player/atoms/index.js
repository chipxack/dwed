export {
    PlayerControlBar,
    DwedPlayerBlock,
    PlayerVolumeBlock,
    PlayerControlRight,
    PlayerControlLeft,
    AnimateButtonsBlock
} from './block'